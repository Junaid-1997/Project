from django.urls import path
from django.urls.resolvers import URLPattern
from . import views
from django.contrib.auth import views as auth_views


urlpatterns = [
    path("", views.home, name = "home"),
    path("mac-address-generator",views.mac_genrator, name = "mac_genrator"),
    path("faq",views.faqs, name = "faqs"),
    path("login",auth_views.LoginView.as_view(template_name="registration/login.html"), name = "login"),
    path("signup",views.register, name = "signup"),
    path("mac-address-lookup",views.mac_lookup, name="mac_lookup"),
    path("logout", auth_views.LogoutView.as_view(template_name="registration/login.html"), name='logout'),
]