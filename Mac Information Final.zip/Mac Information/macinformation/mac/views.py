from django.http.response import HttpResponse
from django.shortcuts import render, redirect
from django.conf import settings
from datetime import datetime
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
from django.contrib.auth import login, authenticate

import json, os, random

with open(os.path.join(settings.BASE_DIR, 'static/macaddress.io-db.json'), encoding='UTF-8') as json_file:
    data = json.load(json_file)

def home(request):
    return render(request, "home.html")

def mac_lookup(request):
    args = {}
    mac_address = request.POST['mac-address-value']
    args['mac_address'] = mac_address
    oui = mac_address.replace("-", ":").upper()[0:8]
    args['oui'] = oui
    output_dict = [x for x in data if x['oui'] == oui]
    
    if output_dict:
        args['isPrivate'] = output_dict[0]['isPrivate']
        args['Is_registered'] = True
        args['Is_valid'] = True
        args['Borderleft'] = oui + ":00:00:00"
        args['Borderright'] = oui + ":FF:FF:FF"
        args['companyName'] = output_dict[0]['companyName']
        args['companyAddress'] = output_dict[0]['companyAddress']
        args['countryCode'] = output_dict[0]['countryCode']
        args['assignmentBlockSize'] = output_dict[0]['assignmentBlockSize']
        args['dateCreated'] = datetime.strptime(output_dict[0]['dateCreated'], r'%Y-%m-%d').strftime("%d %B %Y")
        args['dateUpdated'] = datetime.strptime(output_dict[0]['dateUpdated'], r'%Y-%m-%d').strftime("%d %B %Y")
        return render(request, "macinfo.html", args)
    
    return render(request, "nomacinfo.html", args)

def mac_genrator(request):
    args = {}
    macs = []
    random_mac = lambda : ":".join([f"{random.randint(0, 255):02x}" for _ in range(6)])
    for i in range(0,100):
        macs.append(random_mac())
    args['macs'] = macs
    return render(request, "genmac.html", args)

def faqs(request):
    return render(request,"faq.html")

def login(request):
    return render(request,"login.html")

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            return redirect(reverse_lazy('login'))
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})